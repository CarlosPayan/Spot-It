
package imagen;

import java.awt.*;
import javax.swing.*;


public class Imagen extends JPanel {
	
	public void paintComponent(Graphics g)
	{
		Dimension tam= getSize();
		
		ImageIcon imagen= new ImageIcon(new ImageIcon(getClass().getResource("/imagen/lifestyle_consultant_icon.png")).getImage());
		g.drawImage(imagen.getImage(), 0, 0, tam.width, tam.height,null);
	}

}
