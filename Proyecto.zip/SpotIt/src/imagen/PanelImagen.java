
package imagen;

import java.awt.*;
import javax.swing.*;


public class PanelImagen extends JPanel {
	
	public void paintComponent(Graphics g)
	{
		Dimension tam= getSize();
		
		ImageIcon imagen= new ImageIcon(new ImageIcon(getClass().getResource("/imagen/fondo2.jpg")).getImage());
		g.drawImage(imagen.getImage(), 0, 0, tam.width, tam.height,null);
	}

}
