package entity;

public class Ticket {
	
	private int idTicket;
	private int idEspacio;
	private int numTicket;
	public int getIdTicket() {
		return idTicket;
	}
	public void setIdTicket(int idTicket) {
		this.idTicket = idTicket;
	}
	public int getIdEspacio() {
		return idEspacio;
	}
	public void setIdEspacio(int idEspacio) {
		this.idEspacio = idEspacio;
	}
	public int getNumTicket() {
		return numTicket;
	}
	public void setNumTicket(int numTicket) {
		this.numTicket = numTicket;
	}
	
	

}
