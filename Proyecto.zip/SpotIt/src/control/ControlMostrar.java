package control;
import java.util.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JOptionPane;


public class ControlMostrar {
	private Connection com;
	private Vector estacionamientos,rese�as;
	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	
	public void conectar()
	{
		try{
			//Instanciar el driver y aparta espacio en la memoria
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String connectionUrl1="jdbc:sqlserver://localhost:1433;" + "database=SpotIt;user=sa;password=payan;";
		//Clase de Driver Manager
		com=DriverManager.getConnection(connectionUrl1);
	
		}
		
		catch(ClassNotFoundException cnfe)
		{
			System.out.println(cnfe.getMessage());
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
	}
	
	public Vector llenar(String usuario)
	{
		
		estacionamientos = new Vector();
	
		try{
			
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select Estacionamiento.nombre FROM Estacionamiento,Usuario Where Usuario.idUsuario=Estacionamiento.idUsuario AND Usuario.nombre='"+usuario+"'");
		
			for(int x=0;rs.next();x++)
				{
					estacionamientos.add(rs.getString("nombre"));
					
				}
			}
			catch(SQLException sqle)
			{
				System.out.println(sqle.getMessage());
			}
		return estacionamientos;
		
	}

	public Vector llenarlista2(String est)
	{
		
		rese�as = new Vector();
	
		try{
			
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select Rese�as.rese�a FROM Estacionamiento,Rese�as Where Rese�as.idEstacionamiento=Estacionamiento.idEstacionamiento AND Estacionamiento.nombre='"+est+"'");
		
			for(int x=0;rs.next();x++)
				{
					rese�as.add(rs.getString("rese�a"));
					
				}
			}
			catch(SQLException sqle)
			{
				System.out.println(sqle.getMessage());
			}
		return rese�as;
		
	}
	public int espaciosUsados(String est)
	{
		int espacios=0;
		try{
			
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select COUNT(Espacios.idEspacios) as num From Estacionamiento,Espacios,Ticket Where Espacios.idEspacios=Ticket.idEspacios AND Estacionamiento.idEstacionamiento= Espacios.idEstacionamiento AND Espacios.uso=1 AND Estacionamiento.nombre='"+est+"'");
		
			for(int x=0;rs.next();x++)
				{
					espacios=rs.getInt("num");
					
				}
			}
			catch(SQLException sqle)
			{
				System.out.println(sqle.getMessage());
			}
		return espacios;
	}
	public int espacios(String est)
	{
		int espacios=0;
		try{
			
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select Estacionamiento.numEspacios From Estacionamiento,Usuario Where Estacionamiento.nombre='"+est+"'");
		
			for(int x=0;rs.next();x++)
				{
					espacios=rs.getInt("numEspacios");
					
				}
			}
			catch(SQLException sqle)
			{
				System.out.println(sqle.getMessage());
			}
		return espacios;
	}
	public int ticketTot()
	{
		int ticket=0;
		try{
			
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select COUNT(Espacios.idEspacios) From Espacios,Estacionamiento Where Estacionamiento.idEstacionamiento=");
		
			for(int x=0;rs.next();x++)
				
				{
					ticket=rs.getInt("numEspacios");
					
				}
			}
			catch(SQLException sqle)
			{
				System.out.println(sqle.getMessage());
			}
		return ticket;
	}
	
	public void agregar(String est)
	{
		int espacios=0;
		
		int id;
		int idEst = 0;
		int idEspacio=0;
		int espcont = 0;
		int esptotal=0;
		
		try{
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select Estacionamiento.idEstacionamiento as id From Estacionamiento Where Estacionamiento.nombre='"+est+"'");
			for(int z=0;rs.next();z++)
				
			{
				idEst=rs.getInt("id");
				
			}
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		
		try{
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select COUNT(Espacios.idEspacios) as espacio From Estacionamiento,Espacios,Ticket Where Espacios.idEstacionamiento=Estacionamiento.idEstacionamiento AND Espacios.idEspacios=Ticket.idEspacios  AND Estacionamiento.nombre='"+est+"'");
			for(int z=0;rs.next();z++)
				
			{
				espcont=rs.getInt("espacio");
				
			}
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		
		esptotal=this.espacios(est);
		
		if(espcont<esptotal)
		{
			
			try{
				conectar();
				Statement stm= com.createStatement();
				ResultSet rs =stm.executeQuery("Select Espacios.idEspacios From Espacios Where Espacios.idEstacionamiento="+idEst);
				
					rs.next();
					idEspacio=rs.getInt("idEspacios");
					idEspacio=idEspacio+espcont;
					
						id=this.id()+1;
						try{	
							conectar();
							Statement stm1= com.createStatement();
							Date date = new Date();
							stm1.executeUpdate("Insert into Ticket VALUES("+id+","+idEspacio+",'"+dateFormat.format(date)+"',NULL)");
						
							
							
						}
						catch(SQLException sqle)
						{
							System.out.println(sqle.getMessage());
						}

						try{	
							conectar();
							Statement stm2= com.createStatement();
							stm2.executeUpdate("UPDATE Espacios SET uso=1 FROM Ticket WHERE Espacios.idEspacios=Ticket.idEspacios ");
						
							
							
						}
						catch(SQLException sqle)
						{
							System.out.println(sqle.getMessage());
						}
					
			}
				catch(SQLException sqle)
				{
					System.out.println(sqle.getMessage());
				}
			
			
		}
		else
		{
			JOptionPane.showMessageDialog(null, "No quedan mas espacios");
		}
	
		
	}
	
	public int id()
	{
		int x=0;
		try{
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select COUNT(Ticket.idEspacios) as espacios From Ticket,Espacios Where Ticket.idEspacios=Espacios.idEspacios");
			for(int y=0;rs.next();y++)
				
			{
				x=rs.getInt("espacios");
				
			}
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		return x;
	}
	
	public int numRese�as(String est)
	{
		int x=0;
		try{
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select COUNT(Rese�as.idEstacionamiento) as num From Rese�as,Estacionamiento Where Rese�as.idEstacionamiento=Estacionamiento.idEstacionamiento AND Estacionamiento.nombre='"+est +"'");
			for(int y=0;rs.next();y++)
				
			{
				x=rs.getInt("num");
				
			}
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		return x;
	}
	public String mostrarrese�a(String est,String titulo)
	{
		String rese�a = null;
		try{
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select Rese�as.rese�a as res  From Rese�as,Estacionamiento Where Rese�as.titulo='"+titulo+"' AND Rese�as.idEstacionamiento=Estacionamiento.idEstacionamiento AND Estacionamiento.nombre='"+est +"'");
			for(int y=0;rs.next();y++)
				
			{
				rese�a=rs.getString("res");
				
			}
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		
		return rese�a;
	}
}
