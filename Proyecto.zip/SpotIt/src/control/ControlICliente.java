package control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import entity.Usuario;

public class ControlICliente
{
	private Connection com;
	
	public boolean validar(Usuario usuario)
	{
		conectar();
		boolean resultado = false;
		try{
		Statement stm= com.createStatement();
		ResultSet rs =stm.executeQuery("Select * FROM Usuario Where nombre='"+usuario.getNombre()
		+"' and contrase�a='"+usuario.getContrase�a()+"'");
		
	
		while(rs.next())
			{
			resultado=true;
			}
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
			

				
		
		return resultado;
	}

	public void conectar()
	{
		try{
			//Instanciar el driver y aparta espacio en la memoria
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String connectionUrl1="jdbc:sqlserver://localhost:1433;" + "database=SpotIt;user=sa;password=payan;";
		//Clase de Driver Manager
		com=DriverManager.getConnection(connectionUrl1);
		System.out.println("Conectado");
		}
		
		catch(ClassNotFoundException cnfe)
		{
			System.out.println(cnfe.getMessage());
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
	}

	public void desconectar()
	{
		try{
			if(com!=null)
			{
				com.close();
				com=null;
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		
	}
}
