package control;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

import entity.Usuario;
public class ControlUsuario {
	
	private Connection com;
	
	public void conectar()
	{
		
		try{
			
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String connectionUrl1="jdbc:sqlserver://localhost:1433;" + "database=SpotIt;user=sa;password=payan;";
	
		com=DriverManager.getConnection(connectionUrl1);
		
		}
		
		catch(ClassNotFoundException cnfe)
		{
			System.out.println(cnfe.getMessage());
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
	}

	public void desconectar()
	{
		try{
			if(com!=null)
			{
				com.close();
				com=null;
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		
	}
	public  int alta(Usuario usuario)
	{
		int resultado=0;
		try{	
			conectar();
			Statement stm= com.createStatement();
			resultado=stm.executeUpdate("INSERT INTO Usuario VALUES("+usuario.getIdUsuario()+",'"+usuario.getNombre()+"','"+usuario.getApaterno()+"','"+usuario.getAmaterno()+"','"+usuario.getContrase�a()+"','"+usuario.getEmail()+"')");
			desconectar();
			
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		return resultado;
	}
	public int actualizar(Usuario usuario)
	{
		int resultado=0;
		try{	
			conectar();
			Statement stm= com.createStatement();
			resultado=stm.executeUpdate("UPDATE Usuario SET nombre="+"'"+usuario.getNombre()+"',"+"apaterno="+"'"+usuario.getApaterno()+"',amaterno='"+usuario.getAmaterno()+"',contrase�a="+usuario.getContrase�a()+",email='"+usuario.getEmail()+" Where Usuario.idUsuario="+usuario.getIdUsuario());
		
			desconectar();
			
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		return resultado;
	}
	
	public int eliminar(Usuario usuario)
	{
		int resultado=0;
		try{	
			conectar();
			Statement stm= com.createStatement();
			resultado=stm.executeUpdate("DELETE FROM Usuario Where Usuario.idUsuario="+usuario.getIdUsuario());
		
			desconectar();
			
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		return resultado;
	}


}
