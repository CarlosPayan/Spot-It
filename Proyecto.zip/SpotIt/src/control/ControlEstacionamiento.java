package control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import entity.Estacionamiento;


public class ControlEstacionamiento 
{
private Connection com;
	
 void conectar()
	{
		
		try{
			
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		
		String connectionUrl1="jdbc:sqlserver://localhost:1433;" + "database=SpotIt;user=sa;password=payan;";
	
		com=DriverManager.getConnection(connectionUrl1);
		
		}
		
		catch(ClassNotFoundException cnfe)
		{
			System.out.println(cnfe.getMessage());
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
	}

	public void desconectar()
	{
		try{
			if(com!=null)
			{
				com.close();
				com=null;
				
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		
	}
	public  int alta(Estacionamiento est)
	{
		int resultado=0;
		try{	
			conectar();
			Statement stm= com.createStatement();
			resultado=stm.executeUpdate("INSERT INTO Estacionamiento VALUES("+est.getIdEstacionamiento()+","+est.getIdUsuario()+",'"+est.getNombre()+"',"+est.getNumEspacios()+","+est.getPrecio()+","+est.getLatitud()+","+est.getLongitud()+")");
			desconectar();
			
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		this.espacios(est.getNumEspacios(),est);
		return resultado;
	}
	public int actualizar(Estacionamiento est)
	{
		int resultado=0;
		try{	
			conectar();
			Statement stm= com.createStatement();
			resultado=stm.executeUpdate("UPDATE Estacionamiento SET idUsuario="+""+est.getIdUsuario()+","+"numEspacios="+est.getNumEspacios()+",nombre='"+est.getNombre()+"',precio="+est.getPrecio()+",latitud="+est.getLatitud()+",longitud="+est.getLongitud()+" Where Estacionamiento.idEstacionamiento="+est.getIdEstacionamiento());
		
			desconectar();
			
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		return resultado;
	}
	
	public int eliminar(Estacionamiento est)
	{
		int resultado=0;
		try{	
			conectar();
			Statement stm= com.createStatement();
			resultado=stm.executeUpdate("DELETE FROM Estacionamiento Where Estacionamiento.idEstacionamiento="+est.getIdEstacionamiento());
		
			desconectar();
			
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		return resultado;
	}
	public void espacios(int espacio,Estacionamiento est)
	{
		int x=1;
		int id;
		int num=1;
		
		while(x<=espacio)
		{
			id=this.id()+1;
			try{	
				conectar();
				Statement stm= com.createStatement();
				stm.executeUpdate("Insert into Espacios VALUES("+id+","+est.getIdEstacionamiento()+",0,"+num+")");
			
				desconectar();
				
			}
			catch(SQLException sqle)
			{
				System.out.println(sqle.getMessage());
			}
			x++;
			num++;
		}
	}
	public int id()
	{
		int x;
		x=0;
		try{
			conectar();
			Statement stm= com.createStatement();
			ResultSet rs =stm.executeQuery("Select COUNT(Estacionamiento.idEstacionamiento) as est From Estacionamiento,Espacios Where Espacios.idEstacionamiento=Estacionamiento.idEstacionamiento");
			for(int y=0;rs.next();y++)
				
			{
				x=rs.getInt("est");
				
			}
		}
		catch(SQLException sqle)
		{
			System.out.println(sqle.getMessage());
		}
		return x;
	}

}
