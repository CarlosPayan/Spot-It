package boundary;

import java.awt.*;


import java.awt.event.*;

import javax.swing.*;

import control.ControlEstacionamiento;

import entity.Estacionamiento;


public class FrmEstacionamiento extends JInternalFrame implements ActionListener
{

	private Container c;
	private JPanel central,abajo;
	private JLabel l1,l2,l3,l4,l5,l6,l7;
	private JTextField t1,t2,t3,t4,t5,t6,t7;
	private JButton b1,b2,b3;
	private ControlEstacionamiento control;
	
	public FrmEstacionamiento()
	{
		super("Estacionamiento", true, true, true, true);
		try
		{
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(UnsupportedLookAndFeelException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(InstantiationException e)
		{
			e.printStackTrace();
		}
		catch(IllegalAccessException e)
		{
			e.printStackTrace();
		}
		c=this.getContentPane();
		c.setLayout(new BorderLayout());
		control = new ControlEstacionamiento();
		central=new JPanel();
		central.setLayout(new GridLayout(4,4));
		abajo = new JPanel();
		abajo.setLayout(new FlowLayout());
		
		l1= new JLabel("Id Estacionamiento");
		l2= new JLabel("Id Usuario");
		l7= new JLabel("Nombre del Estacionamiento");
		l3= new JLabel("Numero de Espacios");
		l4=new JLabel("Precio");
		l5= new JLabel("Latitud");
		l6= new JLabel("Longitud");
		
		t1= new JTextField();
		t2= new JTextField();
		t3= new JTextField();
		t4= new JTextField();
		t5= new JTextField();
		t6= new JTextField();
		t7= new JTextField();
		
		b1 = new JButton("Dar de Alta");
		b2 = new JButton("Actualizar");
		b3= new JButton("Eliminar");
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		central.add(l1);
		central.add(t1);
		central.add(l2);
		central.add(t2);
		central.add(l3);
		central.add(t3);
		central.add(l4);
		central.add(t4);
		central.add(l5);
		central.add(t5);
		central.add(l6);
		central.add(t6);
		central.add(l7);
		central.add(t7);
		
		abajo.add(b1);
		abajo.add(b2);
		abajo.add(b3);
		
		c.add(BorderLayout.CENTER,central);
		c.add(BorderLayout.SOUTH,abajo);
		
		this.setVisible(true);
		this.pack();
		
	}
	
	
	public void actionPerformed(ActionEvent e) 
	{
		
		if(e.getSource()==b1)
		{
			int resultado=0;
			Estacionamiento est = new Estacionamiento();
			
			if((t1.getText().equals(""))||(t2.getText().equals(""))||(t3.getText().equals(""))||(t4.getText().equals(""))||(t5.getText().equals(""))||(t6.getText().equals(""))||(t7.getText().equals("")))
			{
				JOptionPane.showMessageDialog(null, "Faltan espacios por llenar");
			}
			else
			{
				
			
				est.setIdEstacionamiento(Integer.parseInt(t1.getText()));
				est.setIdUsuario(Integer.parseInt(t2.getText()));
				est.setNumEspacios(Integer.parseInt(t3.getText()));
				est.setNombre(t7.getText());
				est.setPrecio(Float.parseFloat(t4.getText()));
				est.setLatitud(Float.parseFloat(t5.getText()));
				est.setLongitud(Float.parseFloat(t6.getText()));
				
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
				t6.setText("");
				t7.setText("");
				
				resultado=control.alta(est);
			if(resultado>0)
			{
				JOptionPane.showMessageDialog(null, "Estacionamiento Agregado");
			}
			else
			{
				JOptionPane.showMessageDialog(null, "Estacionamiento No Agregado");
			}
		}
			
		}
		if(e.getSource()==b3)
		{
			int resultado=0;
			Estacionamiento est = new Estacionamiento();
			est.setIdEstacionamiento(Integer.parseInt(t1.getText()));
			resultado=control.eliminar(est);
		if(resultado>0)
		{
			JOptionPane.showMessageDialog(null, "Estacionamiento Eliminado");
		}
		else
		{
			JOptionPane.showMessageDialog(null, "No se encontro el Estacionamiento");
		}
		t1.setText("");
		t2.setText("");
		t3.setText("");
		t4.setText("");
		t5.setText("");
		t6.setText("");
		
		
		}
	
		if(e.getSource()==b2)
		{
			int resultado=0;
		
			if((t1.getText().equals(""))||(t2.getText().equals(""))||(t3.getText().equals(""))||(t4.getText().equals(""))||(t5.getText().equals(""))||(t6.getText().equals(""))||(t7.getText().equals("")))
			{
				JOptionPane.showMessageDialog(null, "Faltan espacios por llenar");
			}
			else
			{
				
			
				Estacionamiento est = new Estacionamiento();
				
				
				est.setIdEstacionamiento(Integer.parseInt(t1.getText()));
				est.setIdUsuario(Integer.parseInt(t2.getText()));
				est.setNumEspacios(Integer.parseInt(t3.getText()));
				est.setPrecio(Float.parseFloat(t4.getText()));
				est.setLatitud(Float.parseFloat(t5.getText()));
				est.setNombre(t7.getText());
				est.setLongitud(Float.parseFloat(t6.getText()));
				
				resultado=control.actualizar(est);
				if(resultado>0)
				{
					JOptionPane.showMessageDialog(null, "Estacionamiento Actualizado");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "No se encontro el Estacionamiento");
				}
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
				t6.setText("");
				t7.setText("");
			}
		}
	
	}
	
	

}
