package boundary;

import java.awt.*;
import java.awt.event.*;
import java.util.Vector;

import javax.swing.*;

import control.ControlMostrar;


public class FrmMostrar extends JFrame implements ActionListener {
	
	private String nueva;
	private Container c;
	private JComboBox lista,lista2;
	private JLabel l1,l2,l3,l4,l5,l6;
	private JButton b1,b2;

	private JPanel norte,sur;

	private Inicio ini;
	private Vector estacionamientos;
	private Vector rese�as;
	private ControlMostrar control;
	private int espaciosUsados=0,espacios=0,espaciosDisponibles=0;
	
	public FrmMostrar(String usuario)
	{
		control = new ControlMostrar();
		c = this.getContentPane();
		c.setLayout(new BorderLayout());
		
		
		norte = new JPanel();
		norte.setLayout(new FlowLayout());
		
	
		sur = new JPanel();
		sur.setLayout(new FlowLayout());
		
		norte.setLayout(new FlowLayout());
	
	
		l1= new JLabel("Usuario: "+usuario);
		l2= new JLabel("Id Estacionamiento");
		l3= new JLabel("Espacios:");
		l5=new JLabel("0");
		
		l4= new JLabel("/");
		
		l6= new JLabel("0");
		b1= new JButton("Agregar Ticket");
		b1.addActionListener(this);
		b2 = new JButton("Regresar");
		b2.addActionListener(this);
		estacionamientos = new Vector();
		estacionamientos=control.llenar(usuario);
		lista = new JComboBox(estacionamientos);
		lista.addActionListener(this);

		norte.add(l1);
		norte.add(l3);
	
		norte.add(l5);
		norte.add(l4);
		norte.add(l6);
		norte.add(l2);
		norte.add(lista);
		
		sur.add(b1);
		sur.add(b2);
		
		
		c.add(BorderLayout.NORTH,norte);
	
		c.add(BorderLayout.SOUTH,sur);
		
		this.setSize(500, 300);
		this.setVisible(true);
		
		
		
		
	}
	
	


	
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==b2)
		{
			ini= new Inicio();
			this.dispose();
		}
		if(e.getSource()==lista)
		{
			espaciosUsados=control.espaciosUsados((lista.getSelectedItem().toString()));
			espacios=control.espacios(lista.getSelectedItem().toString());
			espaciosDisponibles=espacios-espaciosUsados;
			
		
			l6.setText(String.valueOf(espacios));
			l5.setText(String.valueOf(espaciosDisponibles));
			int x=0;
			x=control.numRese�as((lista.getSelectedItem().toString()));
			if(x>0)
			{
				
			}
			else
			{
				JOptionPane.showMessageDialog(null, "No hay rese�as en este Estacionamiento");
			}
		
	
		}
		if(e.getSource()==b1)
		{
			control.agregar((lista.getSelectedItem().toString()));
			espaciosUsados=control.espaciosUsados((lista.getSelectedItem().toString()));
			espacios=control.espacios(lista.getSelectedItem().toString());
			espaciosDisponibles=espacios-espaciosUsados;
			
		
			l6.setText(String.valueOf(espacios));
			l5.setText(String.valueOf(espaciosDisponibles));
		}
		

		
	}
	


}
