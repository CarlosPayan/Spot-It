package boundary;
import java.awt.*;


import java.awt.event.*;

import javax.swing.*;

import control.ControlUsuario;
import entity.Usuario;

public class FrmUsuario extends JInternalFrame implements ActionListener {
	

	private Container c;
	private JPanel central,abajo;
	private JLabel l1,l2,l3,l4,l5,l6;
	private JTextField t1,t2,t3,t4,t5,t6;
	private JButton b1,b2,b3;
	private ControlUsuario control;
	
	public FrmUsuario()
	{
		super("Usuario", true, true, true, true);
		c=this.getContentPane();
		c.setLayout(new BorderLayout());
		control = new ControlUsuario();
		
		central=new JPanel();
		central.setLayout(new GridLayout(2,4));
		abajo = new JPanel();
		abajo.setLayout(new FlowLayout());
		
		l1= new JLabel("Id Usuario");
		l2= new JLabel("Nombre");
		l3= new JLabel("Apellido Paterno");
		l4=new JLabel("Apellido Materno");
		l5= new JLabel("Contrase�a");
		l6= new JLabel("E-Mail");
		
		t1= new JTextField();
		t2= new JTextField();
		t3= new JTextField();
		t4= new JTextField();
		t5= new JTextField();
		t6= new JTextField();

		b1 = new JButton("Dar de Alta");
		b2 = new JButton("Actualizar");
		b3= new JButton("Eliminar");
		
		b1.addActionListener(this);
		b2.addActionListener(this);
		b3.addActionListener(this);
		
		central.add(l1);
		central.add(t1);
		central.add(l2);
		central.add(t2);
		central.add(l3);
		central.add(t3);
		central.add(l4);
		central.add(t4);
		central.add(l5);
		central.add(t5);
		central.add(l6);
		central.add(t6);
		
		abajo.add(b1);
		abajo.add(b2);
		abajo.add(b3);
		
		c.add(BorderLayout.CENTER,central);
		c.add(BorderLayout.SOUTH,abajo);
		
		this.setVisible(true);
		this.pack();
		
	}

	public void actionPerformed(ActionEvent e)
	{
		
		if(e.getSource()==b1)
		{
			int resultado=0;
			if((t1.getText().equals(""))||(t2.getText().equals(""))||(t3.getText().equals(""))||(t4.getText().equals(""))||(t5.getText().equals(""))||(t6.getText().equals("")))
			{
				JOptionPane.showMessageDialog(null, "Faltan espacios por llenar");
			}
			else
			{
				Usuario usr = new Usuario();
				
				usr.setIdUsuario(Integer.parseInt(t1.getText()));
				usr.setNombre(t2.getText());
				usr.setApaterno(t3.getText());
				usr.setAmaterno(t4.getText());
				usr.setContrase�a(t5.getText());
				usr.setEmail(t6.getText());
				
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
				t6.setText("");
			
				
				resultado=control.alta(usr);
			}
		if(resultado>0)
		{
			JOptionPane.showMessageDialog(null, "Usuario Agregado");
		}
		else
		{
			JOptionPane.showMessageDialog(null, "Usuario No Agregado");
		}
			
		}
		if(e.getSource()==b3)
		{
			int resultado=0;
			Usuario usr = new Usuario();
			usr.setIdUsuario(Integer.parseInt(t1.getText()));
			resultado=control.eliminar(usr);
		if(resultado>0)
		{
			JOptionPane.showMessageDialog(null, "Usuario Eliminado");
		}
		else
		{
			JOptionPane.showMessageDialog(null, "No se encontro el Usuario");
		}
		t1.setText("");
		t2.setText("");
		t3.setText("");
		t4.setText("");
		t5.setText("");
		t6.setText("");
		
		
		}
	
		if(e.getSource()==b2)
		{
			int resultado=0;
			if((t1.getText().equals(""))||(t2.getText().equals(""))||(t3.getText().equals(""))||(t4.getText().equals(""))||(t5.getText().equals(""))||(t6.getText().equals("")))
			{
				JOptionPane.showMessageDialog(null, "Faltan espacios por llenar");
			}
			else
			{
				Usuario usr = new Usuario();
				
				usr.setIdUsuario(Integer.parseInt(t1.getText()));
				usr.setNombre(t2.getText());
				usr.setApaterno(t3.getText());
				usr.setAmaterno(t4.getText());
				usr.setContrase�a(t5.getText());
				usr.setEmail(t6.getText());
				
				
				resultado=control.actualizar(usr);
				if(resultado>0)
				{
					JOptionPane.showMessageDialog(null, "Usuario Actualizado");
				}
				else
				{
					JOptionPane.showMessageDialog(null, "No se encontro el Usuario");
				}
				t1.setText("");
				t2.setText("");
				t3.setText("");
				t4.setText("");
				t5.setText("");
				t6.setText("");
			}
		}
	}
	

}
