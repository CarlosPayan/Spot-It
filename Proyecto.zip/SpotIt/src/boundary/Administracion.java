package boundary;
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;



public class Administracion extends JFrame implements ActionListener
{
	private Container c;
	private JDesktopPane desktop;
	private JMenuBar barra;
	private JMenu menu,menu2;
	private JMenuItem i1,i2,i3;
	private FrmUsuario usuario;
	private FrmEstacionamiento estacionamiento;
	private Inicio ini;
	
	public  Administracion()
	{
		try
		{
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(UnsupportedLookAndFeelException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(InstantiationException e)
		{
			e.printStackTrace();
		}
		catch(IllegalAccessException e)
		{
			e.printStackTrace();
		}
		barra = new JMenuBar();
		menu = new JMenu("Acciones");
		menu2= new JMenu("Regresar");
		
		i1 = new JMenuItem( "Administracion de Usuarios" );
		i1.addActionListener(this);
		i2= new JMenuItem("Administracion de Estacionamiento");
		i2.addActionListener(this);
		i3 = new JMenuItem("Regresar a Inicio");
		i3.addActionListener(this);
		menu.add(i1);
		menu.add(i2);
		menu2.add(i3);
		barra.add(menu);
		barra.add(menu2);
		
		this.setJMenuBar(barra);
		
	
		
		c = this.getContentPane();
		desktop = new JDesktopPane();
		c.add(desktop);
		
		
		this.setVisible(true);
		this.setSize(600, 600);
		
	}



	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==i1)
		{
			usuario= new FrmUsuario();
			desktop.add(usuario);
		}
		
		if(e.getSource()==i2)
		{
			estacionamiento = new FrmEstacionamiento();
			desktop.add(estacionamiento);
		}
		if(e.getSource()==i3)
		{
			ini= new Inicio();
			this.dispose();
		}
	}
	
}
