package boundary;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import java.sql.*;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;

import org.jdesktop.swingx.JXMapViewer;
import org.jdesktop.swingx.OSMTileFactoryInfo;
import org.jdesktop.swingx.mapviewer.DefaultTileFactory;
import org.jdesktop.swingx.mapviewer.DefaultWaypoint;
import org.jdesktop.swingx.mapviewer.TileFactoryInfo;
import org.jdesktop.swingx.mapviewer.GeoPosition;
import org.jdesktop.swingx.mapviewer.Waypoint;
import org.jdesktop.swingx.mapviewer.WaypointPainter;

import org.jdesktop.swingx.painter.Painter;
import org.jdesktop.swingx.painter.CompoundPainter;

public class FrmComentario extends JFrame implements ActionListener 
{
	
	private Container c;
	private JPanel panelInferior, panelComentario, panelOpc;
	private JLabel l1;
	private JTextArea t1;
	private JButton b1,b2;
	private JRadioButton rb1,rb2,rb3,rb4,rb5;
	private GridLayout grid;
	
	public FrmComentario()
	{
		
		grid= new GridLayout(5,1);
		c = this.getContentPane();
		l1 = new JLabel("Rese�a");
		t1 = new JTextArea();
		t1.setBounds(10,50,400,300);
		b1= new JButton("Enviar");
		b1.addActionListener(this);
		b2= new JButton("Cancelar");
		b2.addActionListener(this);
		rb1 = new JRadioButton("Pesimo");
		rb1.addActionListener(this);
		rb2 = new JRadioButton("Malo");
		rb2.addActionListener(this);
		rb3 = new JRadioButton("Regular");
		rb3.addActionListener(this);
		rb4 = new JRadioButton("Bueno");
		rb4.addActionListener(this);
		rb5 = new JRadioButton("Excelente");
		rb5.addActionListener(this);
		

		panelComentario=new JPanel();
		panelComentario.add(l1);
		add(t1);
	

		
		panelOpc= new JPanel(grid);
		panelOpc.add(rb1);
		panelOpc.add(rb2);
		panelOpc.add(rb3);
		panelOpc.add(rb4);
		panelOpc.add(rb5);
		
		panelInferior= new JPanel();
		panelInferior.add(b1);
		panelInferior.add(b2);
		
		c.setLayout(new BorderLayout());  
		c.add(panelComentario,BorderLayout.CENTER);
		c.add(panelOpc,BorderLayout.EAST);
		c.add(panelInferior,BorderLayout.SOUTH);
		
		this.setVisible(true);
		this.setSize(550, 550);
	
	}
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==rb1)
		{
			rb2.setSelected(false);
			rb3.setSelected(false);
			rb4.setSelected(false);
			rb5.setSelected(false);
		}
		if(e.getSource()==rb2)
		{
			rb1.setSelected(false);
			rb3.setSelected(false);
			rb4.setSelected(false);
			rb5.setSelected(false);
		}
		if(e.getSource()==rb3)
		{
			rb2.setSelected(false);
			rb1.setSelected(false);
			rb4.setSelected(false);
			rb5.setSelected(false);
		}
		if(e.getSource()==rb4)
		{
			rb2.setSelected(false);
			rb3.setSelected(false);
			rb1.setSelected(false);
			rb5.setSelected(false);
		}
		if(e.getSource()==rb5)
		{
			rb2.setSelected(false);
			rb3.setSelected(false);
			rb4.setSelected(false);
			rb1.setSelected(false);
		}
		if(e.getSource()==b1)
		{
			
		}
		
	}
	public static void main(String[] args)
	{
		FrmComentario app= new FrmComentario();
	}
	

}