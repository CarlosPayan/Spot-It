package boundary;

import imagen.Imagen;
import imagen.PanelImagen;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;



public class Inicio extends JFrame implements ActionListener{

	
	private Container c;
	private JButton b1,b2;
	private JMenuBar menu;
	private JMenu adm;
	private JMenuItem i1;
	private JPanel central;
	private Administracion app;
	private FrmCliente cliente;
	

	public Inicio()
	{
		try
		{
		UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}
		catch(UnsupportedLookAndFeelException e)
		{
			e.printStackTrace();
		}
		catch(ClassNotFoundException e)
		{
			e.printStackTrace();
		}
		catch(InstantiationException e)
		{
			e.printStackTrace();
		}
		catch(IllegalAccessException e)
		{
			e.printStackTrace();
		}
		c = new Container();
		c = this.getContentPane();
		c.setLayout(new BorderLayout());
	
	
		
		b1 = new JButton("Ingreso Cliente");
		b1.add(new Imagen());
		b1.setSize(20, 20);
		b2= new JButton("Localizacion de Estacionamiento");
		b1.addActionListener(this);
		b2.addActionListener(this);
		
		menu = new JMenuBar();
		adm= new JMenu("Administraci�n");
		i1 = new JMenuItem("Ir a Administracion");
		i1.addActionListener(this);
		adm.add(i1);
		
		menu.add(adm);
		this.setJMenuBar(menu);
		central= new JPanel();
	
		central.add(b1);
		central.add(b2);
	
		
		c.add(BorderLayout.CENTER,new PanelImagen());
		
		c.add(BorderLayout.SOUTH,central);
		this.setSize(400, 400);
		
		setVisible(true);
	}
	
	


	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource()==i1)
		{
			this.dispose();
			app= new Administracion();
		}
		if(e.getSource()==b1)
		{
			this.dispose();
			cliente= new FrmCliente();
			
		}
	}

	public static void main(String args[])
	{
		Inicio prueba = new Inicio();
	}
	
}
