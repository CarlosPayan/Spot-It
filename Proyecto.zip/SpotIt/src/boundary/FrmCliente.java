package boundary;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import control.ControlICliente;
import entity.Usuario;


public class FrmCliente extends JFrame implements ActionListener
{

	private Container c;
	private JPanel central,sur;
	private JLabel l1,l2;
	private JTextField t1;
	private JPasswordField t2;
	private JButton b1,b2;
	private FrmMostrar mostrar;
	private Inicio ini;
	
	public FrmCliente()
	{
		c = this.getContentPane();
		c.setLayout(new BorderLayout());
		
		l1= new JLabel("Nombre de Usuario");
		l2= new JLabel("Contrase�a");
		t1 = new JTextField();
		t1.addActionListener(this);
		t2= new JPasswordField();
		t2.addActionListener(this);
		b1= new JButton("Entrar");
		b1.addActionListener(this);
		b2= new JButton("Regresar");
		b2.addActionListener(this);
		
		central = new JPanel();
		central.setLayout(new GridLayout(3,3));
		sur= new JPanel();
		sur.setLayout(new FlowLayout());
		
		central.add(l1);
		central.add(t1);
		central.add(l2);
		central.add(t2);
		
		sur.add(b1);
		sur.add(b2);
		
		c.add(BorderLayout.NORTH,central);
		c.add(BorderLayout.SOUTH,sur);
	
		
		this.setSize(200, 100);
		this.pack();

		setVisible(true);
		
	}

	
	public void actionPerformed(ActionEvent e) 
	{
		if(e.getSource()==b1)
		{
			Usuario usuario = new Usuario();
			usuario.setNombre(t1.getText());
			
			String contrase�a= new String(t2.getPassword());
			usuario.setContrase�a(contrase�a);
					
			ControlICliente control = new ControlICliente();
			boolean resultado = control.validar(usuario);
			
			
			if(resultado == true)
			{
				mostrar= new FrmMostrar(usuario.getNombre());
				this.dispose();
				
			
			}
			if(resultado == false)
			{
				JOptionPane.showMessageDialog(null, "Usuario Inv�lido");
			}
		}
		if(e.getSource()==b2)
		{
			ini= new Inicio();
			this.dispose();
		}
	}
	 
	
	
	
}
